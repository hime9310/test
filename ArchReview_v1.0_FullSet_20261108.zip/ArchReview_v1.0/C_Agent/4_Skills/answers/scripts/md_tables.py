# -*- coding: utf-8 -*-
"""共通部品(全スキルの scripts/ に同じものを置く)。標準ライブラリだけで動く。

できること:
  - read_input      : ツールの返り値ファイルを文字列で読む(BOM / base64 / JSON 包みを自動で外す)
  - read_json_input : JSON を読む(二重に文字列化された JSON も読む)
  - rows_from_json  : Excel「表内に存在する行を一覧表示」の返り値から行の配列だけ取り出す
  - parse_tables    : Markdown の表を {見出し, 列名, 行(dict)} の形にする
  - parse_sections  : 「## 見出し」ごとに「- 」行を集める(成果物 md を読むとき用)
  - normalize / get / split_fields / first_int / dump : 文字の正規化・列名ゆれ吸収・分割・数値取り出し・JSON 出力
"""
import base64
import html
import json
import re
import sys
import unicodedata

BOM = "﻿"


# ---------- 入力の読み込み ----------
def read_input(path, unwrap=True):
    """ファイル(または '-' で標準入力)を文字列で返す。
    1) 文字コードは utf-8 → cp932 の順に試す
    2) unwrap=True のとき、{"$content": "..."} / {"content": "..."} のような JSON 包みなら中の文字列を取り出す
    3) 中身が base64 だけなら復号する(SharePoint のファイル取得が base64 で返す場合がある)
    """
    if path == "-" or path is None:
        data = sys.stdin.buffer.read()
    else:
        with open(path, "rb") as f:
            data = f.read()
    text = _decode_bytes(data).lstrip(BOM)

    stripped = text.strip()
    if unwrap and stripped.startswith("{") and stripped.endswith("}"):
        try:
            obj = json.loads(stripped)
            for key in ("$content", "content", "body", "value", "text"):
                if isinstance(obj.get(key), str):
                    text = obj[key]
                    break
        except Exception:
            pass

    # 日本語も「|」も無く、base64 の文字だけなら復号を試す
    if "|" not in text and not re.search(r"[　-鿿]", text):
        compact = re.sub(r"\s+", "", text)
        if compact and len(compact) % 4 == 0 and re.fullmatch(r"[A-Za-z0-9+/=]+", compact):
            try:
                decoded = _decode_bytes(base64.b64decode(compact, validate=True))
                if "|" in decoded or re.search(r"[　-鿿]", decoded):
                    text = decoded.lstrip(BOM)
            except Exception:
                pass
    return text.replace("\r\n", "\n").replace("\r", "\n")


def _decode_bytes(data):
    """utf-8(BOM あり/なし) → cp932 の順に試して文字列にする。"""
    for enc in ("utf-8-sig", "utf-8", "cp932"):
        try:
            return data.decode(enc)
        except Exception:
            continue
    return data.decode("utf-8", errors="replace")


def read_json_input(path):
    """JSON ファイルを読む。文字列として二重に包まれていても中身を返す。"""
    text = read_input(path, unwrap=False).strip()
    obj = json.loads(text)
    if isinstance(obj, str):
        obj = json.loads(obj)
    return obj


def rows_from_json(obj):
    """ツールの返り値(配列 / {"value":[...]} / {"body":{"value":[...]}})から行の配列を取り出す。"""
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for key in ("value", "rows", "items", "body"):
            v = obj.get(key)
            if isinstance(v, list):
                return v
            if isinstance(v, dict):
                r = rows_from_json(v)
                if r:
                    return r
    return []


# ---------- 文字の正規化 ----------
def normalize(s):
    """照合用: 全角半角をそろえ、小文字にし、空白と記号を消す(例 'Amazon S3' と 'amazons3' が同じになる)。"""
    if s is None:
        return ""
    s = unicodedata.normalize("NFKC", str(s)).lower()
    s = re.sub(r"[\s　]+", "", s)
    s = re.sub(r"[()\[\]{}（）「」『』【】・,.、。/／:：;；\-_－—–\"'`’‘”“*]+", "", s)
    return s


def cell_lines(s):
    """セル内の改行(<br> または実改行)で分け、空行を除いた一覧を返す。"""
    if s is None:
        return []
    s = re.sub(r"<br\s*/?>", "\n", str(s), flags=re.I)
    return [x.strip() for x in s.split("\n") if x.strip()]


# ---------- Markdown の表 ----------
def _split_row(line):
    """'| a | b |' を ['a', 'b'] にする(セル内の \\| はそのまま | として扱う)。"""
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    cells = re.split(r"(?<!\\)\|", line)
    return [html.unescape(c.replace("\\|", "|")).strip() for c in cells]


def _is_separator(line):
    """'|---|---|' の区切り行か。"""
    return bool(re.fullmatch(r"\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?", line.strip()))


def parse_tables(text):
    """文書中のすべての表を返す。各表は {"title": 直前の見出し, "headers": [...], "rows": [dict, ...]}。"""
    lines = text.split("\n")
    tables = []
    current_title = ""
    i = 0
    while i < len(lines):
        line = lines[i]
        if re.match(r"^#{1,6}\s+", line):  # 見出しを覚えておく(表の名前になる)
            current_title = re.sub(r"^#{1,6}\s+", "", line).strip()
            i += 1
            continue
        if line.strip().startswith("|") and i + 1 < len(lines) and _is_separator(lines[i + 1]):
            headers = _split_row(line)
            i += 2
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = _split_row(lines[i])
                cells += [""] * (len(headers) - len(cells))
                rows.append(dict(zip(headers, cells)))
                i += 1
            tables.append({"title": current_title, "headers": headers, "rows": rows})
            continue
        i += 1
    return tables


def find_table(tables, header_keywords=None, title_keywords=None):
    """見出しの語か列名の語で表を1つ選ぶ。見つからなければ None。"""
    for t in tables:
        if title_keywords and any(k in t["title"] for k in title_keywords):
            return t
    if header_keywords:
        for t in tables:
            hs = [normalize(h) for h in t["headers"]]
            if all(any(normalize(k) == h or normalize(k) in h for h in hs) for k in header_keywords):
                return t
    return None


def find_column(headers, *keywords):
    """列名の一覧から、キーワード(部分一致・大小無視)に合う最初の列名を返す。無ければ ''。"""
    for h in headers:
        nh = normalize(h)
        if any(normalize(k) in nh for k in keywords):
            return h
    return ""


def get(row, *names, default=""):
    """行(dict)から、列名のゆれ(空白・全角半角・記号)を吸収して値を取る。"""
    keys = {normalize(k): k for k in row.keys()}
    for n in names:
        k = keys.get(normalize(n))
        if k is not None and row[k] not in (None, ""):
            return str(row[k])
    return default


# ---------- 成果物(箇条書き形式)の読み込み ----------
def parse_sections(text):
    """'## 見出し' ごとに '- ' 行を集めて {"見出し": ["行", ...]} を返す。
    見出しの括弧より前だけのキー(例 'サービス一覧(5件)' → 'サービス一覧')も作る。"""
    sections = {"_head": []}
    current = "_head"
    for line in text.split("\n"):
        m = re.match(r"^##\s+(.*)$", line)
        if m:
            current = m.group(1).strip()
            sections[current] = []
            continue
        if line.strip().startswith("- "):
            sections[current].append(line.strip()[2:].strip())
    for k in list(sections.keys()):
        base = re.sub(r"[(（].*$", "", k).strip()
        if base and base not in sections:
            sections[base] = sections[k]
    return sections


def section(sections, prefix):
    """見出しが prefix で始まる節の行一覧を返す(無ければ [])。"""
    for k, v in sections.items():
        if k.startswith(prefix):
            return v
    return []


def split_fields(line):
    """'a｜b｜c' を ['a','b','c'] に分ける(全角｜・半角| の両方)。"""
    return [x.strip() for x in re.split(r"[｜|]", line)]


def first_int(s, default=None):
    """文字列の中の最初の整数を返す(全角数字も可)。"""
    m = re.search(r"\d+", unicodedata.normalize("NFKC", str(s)))
    return int(m.group()) if m else default


def dump(obj):
    """結果を JSON(日本語そのまま)で標準出力に書く。"""
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
