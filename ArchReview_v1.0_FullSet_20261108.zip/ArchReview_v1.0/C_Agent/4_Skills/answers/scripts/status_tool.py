# -*- coding: utf-8 -*-
"""全スキル共通: SharePoint List「アーキテクチャレビュー案件状態管理」の1行(案件状態)を更新する値を作る。

流れ: ワークフロー「案件状態_取得」が返す 状態テキスト を work/status.txt に保存 → このスクリプトで新しい値を作る
      → 出力 JSON の各キーを ワークフロー「案件状態_更新」の同名の入力に渡す(List への書き込みはワークフローが行う)。

使い方(例):
  工程の終わり : python scripts/status_tool.py --current work/status.txt --ritm RITM1234567 --step "判定(完了)" --next "『構成図チェックして』" --env Hub --csp AWS
  失敗したとき : python scripts/status_tool.py --current work/status.txt --ritm RITM1234567 --step "判定(失敗)" --next "『ホスティング判定して』をもう一度" --error "Teams の返信が取れない"
  値だけ変える : python scripts/status_tool.py --current work/status.txt --ritm RITM1234567 --env Disconnected
  新規(作成直後): python scripts/status_tool.py --ritm RITM1234567 --item-id 12 --step "Mermaid化(完了)" --next "『構成図情報を抽出して』" --team … --channel … --message … --link …

--step は「工程名(状態)」。状態は 完了 / 要確認 / 失敗 / 未着。
  完了 → List の状態は 進行中(工程名が ナレッジ文案 なら 完了)、要確認 → 要確認、失敗 → 失敗(--error を最終エラーに)、未着 → 未着。
  失敗の後に同じ工程が成功したら 再試行回数 を 1 増やし、最終エラーを空にする。
"""
import argparse
import datetime
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import read_input, dump  # noqa: E402

# 出力 JSON のキー = ワークフロー「案件状態_更新」の入力名(順番もこのとおり)
FIELDS = ["項目ID", "RITM番号", "案件名", "状態", "現在の工程", "次の操作", "完了した工程", "対象環境", "CSP",
          "Teams_team", "Teams_channel", "Teams_message", "スレッドリンク", "案件フォルダ", "票リンク",
          "最終エラー", "再試行回数"]
DEFAULTS = {"状態": "進行中", "現在の工程": "", "完了した工程": "なし", "対象環境": "未定", "CSP": "未定", "再試行回数": "0"}


def parse_status_text(text):
    """案件状態_取得 が返す 状態テキスト を {列名: 値} にする。無い行は既定値。"""
    d = {k: DEFAULTS.get(k, "") for k in FIELDS}

    def after(label, line):
        return line.split(label, 1)[1].strip()

    for raw in text.split("\n"):
        line = raw.strip().lstrip("- ").strip()
        if line.startswith("【案件状態】RITM:"):
            d["RITM番号"] = after("RITM:", line)
        elif line.startswith("項目ID:"):
            d["項目ID"] = after("項目ID:", line)
        elif line.startswith("案件名:"):
            d["案件名"] = after("案件名:", line)
        elif line.startswith("状態:"):
            m = re.match(r"状態:\s*([^｜|]*)[｜|]\s*現在の工程:\s*(.*)$", line)
            if m:
                d["状態"], d["現在の工程"] = m.group(1).strip() or "進行中", m.group(2).strip()
        elif line.startswith("対象環境:"):
            m = re.match(r"対象環境:\s*([^｜|]*)[｜|]\s*CSP:\s*(.*)$", line)
            if m:
                d["対象環境"], d["CSP"] = m.group(1).strip() or "未定", m.group(2).strip() or "未定"
        elif line.startswith("完了した工程:"):
            d["完了した工程"] = after("完了した工程:", line) or "なし"
        elif line.startswith("次の操作:"):
            d["次の操作"] = after("次の操作:", line)
        elif line.startswith("Teamsスレッド:"):
            m = re.search(r"team=([^｜|\s]*)\s*[｜|]\s*channel=([^｜|\s]*)\s*[｜|]\s*message=(\S*)", line)
            if m:
                d["Teams_team"], d["Teams_channel"], d["Teams_message"] = m.groups()
        elif line.startswith("スレッドリンク:"):
            d["スレッドリンク"] = after("スレッドリンク:", line)
        elif line.startswith("案件フォルダ:"):
            d["案件フォルダ"] = after("案件フォルダ:", line)
        elif line.startswith("票リンク:"):
            d["票リンク"] = after("票リンク:", line)
        elif line.startswith("最終エラー:"):
            m = re.match(r"最終エラー:\s*(.*?)\s*[｜|]\s*再試行回数:\s*(\d*)", line)
            if m:
                d["最終エラー"], d["再試行回数"] = m.group(1).strip(), m.group(2) or "0"
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--current", help="案件状態_取得 の 状態テキスト を保存したファイル(新規のときは省略)")
    ap.add_argument("--ritm", required=True)
    ap.add_argument("--item-id", help="案件状態_作成 が返した 項目ID(新規のときだけ)")
    ap.add_argument("--step", help="工程名(状態)。例: 判定(完了)")
    ap.add_argument("--next", help="次の操作(1番だけ)")
    ap.add_argument("--env", help="Hub / Disconnected")
    ap.add_argument("--csp", help="AWS / Azure / GCP")
    ap.add_argument("--team")
    ap.add_argument("--channel")
    ap.add_argument("--message")
    ap.add_argument("--link", help="スレッドリンク")
    ap.add_argument("--case-name")
    ap.add_argument("--folder", help="案件フォルダのパス")
    ap.add_argument("--sheet-link", help="作成した Excel のリンク")
    ap.add_argument("--error", help="失敗の理由(--step が 失敗 のとき)")
    a = ap.parse_args()

    # 1. 今の値を読む(無ければ既定値)
    text = read_input(a.current) if a.current and os.path.exists(a.current) else ""
    d = parse_status_text(text)
    d["RITM番号"] = a.ritm
    if a.item_id:
        d["項目ID"] = str(a.item_id).strip()
    before_status = d["状態"]

    # 2. 指定された値だけ上書きする
    if a.env:
        d["対象環境"] = a.env.replace("DCS", "").strip()
    if a.csp:
        d["CSP"] = a.csp.strip()
    for key, val in (("Teams_team", a.team), ("Teams_channel", a.channel), ("Teams_message", a.message),
                     ("スレッドリンク", a.link), ("案件名", a.case_name), ("案件フォルダ", a.folder), ("票リンク", a.sheet_link)):
        if val:
            d[key] = val.strip()
    if a.next:
        d["次の操作"] = a.next.strip()

    # 3. 工程の記録と状態の決定
    if a.step:
        m = re.match(r"^(.*?)[(（](完了|要確認|失敗|未着)[)）]\s*$", a.step.strip())
        if not m:
            sys.exit("--step は「工程名(完了|要確認|失敗|未着)」の形で指定してください")
        name, result = m.group(1).strip(), m.group(2)
        steps = [s for s in re.split(r"[｜|]", d["完了した工程"]) if s.strip() and s.strip() != "なし"]
        steps = [s for s in steps if re.sub(r"[(（].*$", "", s).strip() != name] + [f"{name}({result})"]
        d["完了した工程"] = "｜".join(steps)
        d["現在の工程"] = name
        if result == "完了":
            d["状態"] = "完了" if name == "ナレッジ文案" else "進行中"
        else:
            d["状態"] = result
        if result == "失敗":
            d["最終エラー"] = (a.error or "理由未記入").strip()
        elif before_status == "失敗":  # 失敗の後にやり直して成功した
            d["再試行回数"] = str(int(d["再試行回数"] or 0) + 1)
            d["最終エラー"] = ""

    # 4. 出力(キーの順はワークフローの入力順)
    out = {k: d[k] for k in FIELDS}
    out["_更新日"] = datetime.date.today().isoformat()
    out["_説明"] = "各キーをワークフロー「案件状態_更新」の同名の入力にそのまま渡す(_ で始まるキーは渡さない)"
    dump(out)


if __name__ == "__main__":
    main()
