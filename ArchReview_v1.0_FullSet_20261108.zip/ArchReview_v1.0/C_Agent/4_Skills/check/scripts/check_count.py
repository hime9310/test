# -*- coding: utf-8 -*-
"""check 用 検算: 埋めた【構成図チェック結果】を読み、[ ] の残り・区分ごとの件数・検算行を確かめる。

使い方: python scripts/check_count.py --result work/04_check.md --count 6   (--count は filter_points の count)
出力(JSON): counts(観点ごとの判定の行から数えた区分の件数)、kensan_line / conclusion_line(そのまま写せる行)、
            placeholders_left(残っている [ ])、unparsed_rows(読めない行)、duplicate_no、ok。
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, parse_sections, read_input, section  # noqa: E402

NAMES = ["票で確認", "利用者へ依頼", "Eng目視確認", "要人手確認", "問題なし", "対象外"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--count", type=int, required=True)
    a = ap.parse_args()
    text = read_input(a.result)
    rows = section(parse_sections(text), "観点ごとの判定")

    # 1. 「- No.X 観点名 → 区分(…)｜…」の行から区分を数える
    counts = {n: 0 for n in NAMES}
    unknown, nos = [], []
    for line in rows:
        m = re.match(r"No\.?\s*(\d+)\s+(.*?)\s*→\s*([^(（｜|]+)", line)
        label = m.group(3).strip() if m else ""
        hit = next((n for n in NAMES if label.startswith(n)), None)
        if not m or not hit:
            unknown.append(line[:60])
            continue
        nos.append(m.group(1))
        counts[hit] += 1

    # 2. 残っている [ ](チェックボックス [x] や [1] は除く)
    placeholders = [p for p in re.findall(r"\[[^\]\n]{1,40}\]", text) if not re.fullmatch(r"\[(x|X|\d+)\]", p)]

    # 3. 件数と状態行
    total = sum(counts.values())
    need = counts["票で確認"] + counts["利用者へ依頼"] + counts["Eng目視確認"] + counts["要人手確認"]
    first = text.strip().split("\n")[0] if text.strip() else ""
    want_status = "要確認" if (counts["Eng目視確認"] or counts["要人手確認"]) else "完了"
    status_ok = not (want_status == "要確認" and "要確認" not in first)  # 要確認が必要なのに 完了 になっていたら NG
    dup = sorted({n for n in nos if nos.count(n) > 1})

    dump({
        "rows": len(rows), "count": a.count, "counts": counts, "need_action": need,
        "placeholders_left": placeholders, "unparsed_rows": unknown, "duplicate_no": dup,
        "expected_status": want_status, "status_line": first,
        "kensan_line": f"- 票で確認{counts['票で確認']} + 利用者へ依頼{counts['利用者へ依頼']} + Eng目視確認{counts['Eng目視確認']} + 要人手確認{counts['要人手確認']} + 問題なし{counts['問題なし']} + 対象外{counts['対象外']} = {total}(適用行数 {a.count} と一致)",
        "conclusion_line": f"- 対応が必要 {need}件(票で確認{counts['票で確認']}・利用者へ依頼{counts['利用者へ依頼']}・Eng目視確認{counts['Eng目視確認']}・要人手確認{counts['要人手確認']}) ｜ 問題なし {counts['問題なし']}件 ｜ 対象外 {counts['対象外']}件",
        "ok": (total == a.count == len(rows)) and not placeholders and not unknown and not dup and status_ok,
    })


if __name__ == "__main__":
    main()
