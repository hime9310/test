# -*- coding: utf-8 -*-
"""hosting 用: ノックアウト要件一覧の全行数と ID を数え(事前)、【ホスティング判定結果】の検算を確かめる(事後)。

使い方:
  事前: python scripts/check_hosting.py --ko work/ko.md
        → ko_total(全行数)、ko_ids、ai_no_judge_ids(備考に「AIは判断しない」「利用者に確認」などがある行)
  事後: python scripts/check_hosting.py --ko work/ko.md --result work/03_hosting.md [--inventory work/02_inventory.md]
        → 判定結果に出てきた ID の過不足、Salus 照合の件数、ko_check_line、ok
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, find_table, first_int, get, parse_sections, parse_tables, read_input, section, split_fields  # noqa: E402

NO_JUDGE = re.compile(r"AI(は|による).{0,8}(判断|判定)(は|を)?(行わず|しない)|利用者に確認|人が行う")


def ko_rows(text):
    """ノックアウト要件一覧(md の表)を {id, ai_no_judge} の一覧にする。"""
    tables = parse_tables(text)
    t = find_table(tables, header_keywords=["ID", "判断区分"]) or (tables[0] if tables else {"rows": []})
    rows = []
    for r in t["rows"]:
        kid = get(r, "ID").strip()
        if kid:
            rows.append({"id": kid, "ai_no_judge": bool(NO_JUDGE.search(get(r, "備考")))})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ko", required=True)
    ap.add_argument("--result")
    ap.add_argument("--inventory")
    a = ap.parse_args()

    rows = ko_rows(read_input(a.ko))
    out = {"ko_total": len(rows), "ko_ids": [r["id"] for r in rows],
           "ai_no_judge_ids": [r["id"] for r in rows if r["ai_no_judge"]]}
    if not a.result:
        dump(out)
        return

    # ---- 事後: 判定結果の「ノックアウト要件 照合」節を読む ----
    sec = parse_sections(read_input(a.result))
    non_ids, individual = [], []
    for line in section(sec, "ノックアウト要件"):
        if line.startswith("非該当"):                      # 非該当(NN件): KO-01, KO-02, …
            non_ids = re.findall(r"KO-\d+", line)
        elif re.match(r"KO-\d+", line):                    # 個別の行: KO-07｜判断区分｜結果｜根拠
            individual.append(split_fields(line)[0])
    listed = set(non_ids) | set(individual)
    out.update({
        "non_ids": non_ids, "result_individual_ids": individual,
        "missing_ids": [r["id"] for r in rows if r["id"] not in listed],   # 一覧にあるのに結果に無い
        "unknown_ids": sorted(listed - set(out["ko_ids"])),                 # 結果にあるのに一覧に無い
        "ko_check_line": f"ノックアウト要件: 非該当{len(non_ids)} + 個別{len(individual)} = {len(non_ids) + len(individual)}(ツールの全行数{len(rows)}と一致)",
    })
    ok = len(non_ids) + len(individual) == len(rows) and not out["missing_ids"] and not out["unknown_ids"]

    # ---- Salus 照合の件数 = サービス一覧の件数 か ----
    if a.inventory:
        svc = [x for x in section(parse_sections(read_input(a.inventory)), "サービス一覧") if "｜" in x or "|" in x]
        counts = {}
        for line in section(sec, "Salus"):
            m = re.match(r"(TRUE|FALSE|未照合)\((\d+)件\)", line.replace(" ", ""))
            if m:
                counts[m.group(1)] = int(m.group(2))
        out["inventory_service_count"] = len(svc)
        out["salus_counts"] = counts
        out["salus_ok"] = sum(counts.values()) == len(svc)
        ok = ok and out["salus_ok"]
    out["ok"] = ok
    dump(out)


if __name__ == "__main__":
    main()
