# -*- coding: utf-8 -*-
"""hosting 用: 【構成図一覧】のサービス一覧を Salus Status 一覧と機械的に照合する。

使い方: python scripts/salus_match.py --inventory work/02_inventory.md --salus work/salus.md [--csp AWS]
出力(JSON): TRUE / FALSE / 未照合 のサービス名と件数、未照合の候補(LLM が目視で確認する用)、check_line、ok。

照合の順: 正式名の完全一致 → 表示ラベルの完全一致 → 部分一致(どちらかがどちらかを含む。候補が1つのときだけ)。
Salus 一覧の列名はゆれてよい(サービス名 / list_name / name、status / isCloudServiceAssessed / 判定、csp / provider など)。
--csp を付けると、その CSP の行と、CSP が AWS/Azure/GCP のどれでもない行(GITHUB など)だけを照合に使う。
"""
import argparse
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, find_column, normalize, parse_sections, parse_tables, read_input, section, split_fields  # noqa: E402

GENERIC = {"amazon", "aws", "azure", "microsoft", "google", "cloud", "gcp", "service", "services"}
TRUE_WORDS = ("TRUE", "〇", "○", "YES", "1", "可")


def tokens(name):
    """候補探し用: 名前を単語に分け、一般語(amazon, aws など)を除く。"""
    s = unicodedata.normalize("NFKC", name).lower()
    return [t for t in re.split(r"[^a-z0-9぀-鿿]+", s) if t and t not in GENERIC]


def load_services(path):
    """【構成図一覧】のサービス一覧: ノードID｜表示ラベル｜正式名｜配置 を読む。"""
    out = []
    for line in section(parse_sections(read_input(path)), "サービス一覧"):
        f = split_fields(line)
        if len(f) >= 2:
            formal = f[2] if len(f) > 2 and f[2] not in ("-", "") else ""
            out.append({"node": f[0], "label": f[1], "formal": formal})
    return out


def load_salus(path, csp):
    """Salus 一覧(md の表)を {name, status} の一覧にする。列名はキーワードで探す。"""
    tables = parse_tables(read_input(path))
    if not tables:
        return []
    t = max(tables, key=lambda x: len(x["rows"]))  # 一番行数の多い表を使う
    col_name = find_column(t["headers"], "サービス名", "list_name", "service", "name", "サービス")
    col_status = find_column(t["headers"], "status", "assessed", "ステータス", "判定", "利用可")
    col_csp = find_column(t["headers"], "csp", "provider", "cloud", "クラウド")
    out = []
    for r in t["rows"]:
        name = (r.get(col_name) or "").strip()
        if not name:
            continue
        if csp and col_csp:
            c = (r.get(col_csp) or "").strip().lower()
            if c in ("aws", "azure", "gcp") and c != csp.lower():
                continue  # 他の CSP の行は使わない
        status = (r.get(col_status) or "").strip().upper()
        out.append({"name": name, "status": "TRUE" if status in TRUE_WORDS else ("FALSE" if status else "")})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--inventory", required=True)
    ap.add_argument("--salus", required=True)
    ap.add_argument("--csp", help="AWS / Azure / GCP(付けるとその CSP の行だけ照合)")
    a = ap.parse_args()

    services = load_services(a.inventory)
    salus = load_salus(a.salus, a.csp)
    index = {normalize(s["name"]): s for s in salus}

    result = {"TRUE": [], "FALSE": [], "未照合": [], "candidates": []}
    for s in services:
        hit = None
        # 1) 完全一致(正式名 → 表示ラベル)
        for key in (s["formal"], s["label"]):
            if key and normalize(key) in index:
                hit = index[normalize(key)]
                break
        # 2) 部分一致(候補が1つのときだけ採用)
        if hit is None:
            for key in (s["formal"], s["label"]):
                nk = normalize(key)
                if len(nk) < 3:
                    continue
                part = [x for x in salus if nk in normalize(x["name"]) or normalize(x["name"]) in nk]
                if len(part) == 1:
                    hit = part[0]
                    break
        display = s["formal"] or s["label"]
        if hit:
            shown = display if normalize(hit["name"]) == normalize(display) else f"{display}(Salus: {hit['name']})"
            result[hit["status"] or "未照合"].append(shown)
        else:
            result["未照合"].append(display)
            toks = set(tokens(display))
            result["candidates"].append({"service": display, "node": s["node"],
                                         "salus_candidates": [x["name"] for x in salus if toks & set(tokens(x["name"]))][:5]})

    n = len(services)
    t, f, u = len(result["TRUE"]), len(result["FALSE"]), len(result["未照合"])
    result.update({
        "counts": {"service_total": n, "TRUE": t, "FALSE": f, "未照合": u},
        "check_line": f"Salus照合: TRUE {t} + FALSE {f} + 未照合{u} = {n}(サービス一覧{n}件と一致)",
        "ok": t + f + u == n,
        "salus_rows_used": len(salus),
    })
    dump(result)


if __name__ == "__main__":
    main()
