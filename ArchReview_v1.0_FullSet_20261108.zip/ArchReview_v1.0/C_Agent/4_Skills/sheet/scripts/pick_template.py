# -*- coding: utf-8 -*-
"""sheet 用: 01_参照データ の一覧から、CSP に合うテンプレート(最新版)を選ぶ。
使い方: python scripts/pick_template.py --list work/ref_list.json --csp AWS
出力(JSON): ok / id / path / name / version / table / reason(選べないときだけ)
"""
import argparse, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, read_json_input, rows_from_json  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--list", required=True)  # 参照_フォルダ一覧取得 の返り値
ap.add_argument("--csp", required=True)   # AWS / Azure / GCP
a = ap.parse_args()

# 1. xlsx のファイルで、名前に「(CSP)」を含むものだけ残す(雛形「(CSP名)」は自然に除かれる)
csp = re.compile(r"[(（]" + re.escape(a.csp.strip()) + r"[)）]", re.I)
hits = []
for f in rows_from_json(read_json_input(a.list)):
    name = f.get("Name") or str(f.get("Path", "")).rsplit("/", 1)[-1]
    if f.get("IsFolder") in (True, "true") or not name.lower().endswith(".xlsx") or not csp.search(name):
        continue
    m = re.search(r"_v([\d.]+)\.xlsx$", name, re.I)          # 版番号 _v2.10 → (2, 10)
    ver = tuple(int(x) for x in m.group(1).split(".") if x) if m else ()
    hits.append({"name": name, "id": f.get("Id", ""), "path": f.get("Path", ""), "ver": ver})

# 2. 一番新しい版を選ぶ。0件、または同じ版が2つ以上なら選ばない
hits.sort(key=lambda h: h["ver"], reverse=True)
out = {"ok": False, "csp": a.csp, "table": "T_アーキテクチャレビュー票"}
if not hits:
    out["reason"] = f"01_参照データ に ({a.csp}) を含む xlsx がありません"
elif len(hits) > 1 and hits[0]["ver"] == hits[1]["ver"]:
    out["reason"] = "同じ版のテンプレートが複数あります。古い方を削除してください"
else:
    b = hits[0]
    out.update(ok=True, id=b["id"], path=b["path"], name=b["name"], version=".".join(map(str, b["ver"])))
dump(out)
