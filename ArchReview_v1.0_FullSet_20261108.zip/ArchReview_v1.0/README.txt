アーキテクチャレビューAgent(New experience 版)ファイル一式 v1.0  2026-11-08

■ フォルダ
A_Docs   … 読む資料。全体設計書、運用手順書、01_参照データ に置く README
B_Setup  … 作る手順。セットアップ手順書、SharePoint List の作り方、VS Code の設定
C_Agent  … エージェントの中身。指示文・設定、ツール、ワークフロー、スキル
D_Test   … 確かめる資料。一連テスト、よくある質問(困ったとき)

■ 読む順
はじめての人: A_Docs/Design.md → B_Setup/Setup.md
作る人:       B_Setup/Setup.md の順に進め、値は C_Agent のファイルを見る
使う人(Eng): A_Docs/Operations.md の1章
直す人:       A_Docs/Operations.md の2章(何を変えたら、どこを直すか)

■ ファイル一覧
A_Docs/Design.md              全体設計書(なぜこの作りか、全体の構成、工程と検算)
A_Docs/Operations.md          運用手順書(日々の使い方、変更するときの手順)
A_Docs/RefData_README.md      SharePoint の 01_参照データ フォルダに置く README(参照データの更新ルール)
B_Setup/Setup.md              セットアップ手順書(作る順番と各手順)
B_Setup/List.md               SharePoint List「アーキテクチャレビュー案件状態管理」の作り方
B_Setup/vscode_settings.json  SKILL.md を編集するときの VS Code 設定(保存時の自動整形を止める)
C_Agent/1_Agent/Instructions.txt  指示文(作成 > 指示 に貼る)
C_Agent/1_Agent/Settings.md       エージェントの設定値(名前・モデル・ナレッジ・あいさつ など)
C_Agent/2_Tools/Tools.md          ツール15本の追加手順と設定値
C_Agent/3_Workflows/Flows.md      エージェント フロー4本の作り方
C_Agent/3_Workflows/OfficeScript_RowAdd.txt  Office スクリプト「アーキテクチャレビュー_行追加」
C_Agent/4_Skills/<スキル名>/      スキル8本(SKILL.md と scripts/)。<スキル名>_v1.0.zip がアップロード用
D_Test/TestSet.md             一連テスト(工程ごとの期待結果)
D_Test/FAQ.md                 よくある質問と、困ったときの見る所

■ 注意
- ファイル名は半角英数字、中身は UTF-8(BOM なし)
- diagram と sheet の SKILL.md は、実際にエージェントに登録した版(Grace さんが手元で編集したもの)が正。この一式の版は同じ内容のつもりだが、違いがあれば登録した版を優先する
- 以前の一式(ArchReview_NewUI_*、ArchReview_NewExperience_v1.0_2026110x)は破棄してよい
