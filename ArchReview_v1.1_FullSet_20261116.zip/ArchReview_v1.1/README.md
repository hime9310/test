# DTG_Architecture_Review_Agent ― ドキュメントと登録物の一式(v1.1 / 2026-11-16)

Copilot Studio(New experience)で作ったアーキテクチャレビュー支援エージェントの、設計書・運用手順書・登録している実物・確認の手順をまとめたもの。

## フォルダ

| フォルダ | 中身 | 読む人 |
|---|---|---|
| A_Docs | 読む資料。エージェント設計書、スキル設計書、運用手順書、参照データの README | 全員 |
| C_Agent | エージェントの中身。登録している実物(指示文、設定値、ツール、フロー、スキル9本) | 作る人・直す人 |
| D_Test | 確かめる資料。正常性確認の手順書、困ったとき | 確認する人・使う人 |

B_Setup(作る手順)は、環境が構築済みのため一式から外した。一から作り直すときは v1.0 の B_Setup を参照する。

## 読む順

- はじめての人: A_Docs/01_Design.md(1〜4章)→ 03_Operations.md(1章)
- 使う人(Eng): A_Docs/03_Operations.md の1章 → 困ったら D_Test/FAQ.md
- 業務のデータで確かめる人: D_Test/UAT_Guide.md
- 直す人: A_Docs/03_Operations.md の2章以降 → 02_Skills.md → C_Agent

## ファイル一覧

```
README.md                          この文書
A_Docs/
  01_Design.md                     エージェント設計書(目的、作りの考え方、構成、一連の動き、工程ごとの動作、案件の記録、使わないもの、制約)
  02_Skills.md                     スキル設計書(共通の作り、9本の要点、スクリプト一覧、版の履歴)
  03_Operations.md                 運用手順書(日々の使い方、変更するとき、Git 管理、変えてはいけないもの)
  04_RefData_README.md             参照データの README(SharePoint の参照データフォルダにも置く)
C_Agent/
  1_Agent/Instructions.txt         指示文 v1.0g(作成 > 指示 に貼る全文)
  1_Agent/Settings.md              エージェントの設定値
  2_Tools/Tools.md                 ツール16本(フロー4 + 直接12)の設定値 v1.1
  3_Workflows/Flows.md             エージェント フロー4本の作り方 v1.1
  3_Workflows/OfficeScript_RowAdd.txt  Office スクリプト「アーキテクチャレビュー_行追加」
  4_Skills/<スキル名>/             スキルの中身(SKILL.md、scripts/)。9本、すべて v1.1
  4_Skills/<スキル名>_v1.1.zip     登録用の zip(上のフォルダと同じ中身)
D_Test/
  UAT_Guide.md                     正常性確認の手順書(業務を知る人向け。スレッドへの投稿からクローズまで)
  FAQ.md                           よくある質問と、困ったとき(症状 → 原因 → 直し方)
```

## 登録している版(2026-11-16)

| もの | 版 |
|---|---|
| 指示文 | v1.0g |
| スキル 9本(diagram / extract / hosting / check / insight / sheet / answers / knowledge / status) | v1.1 |
| ツール | 16本(Tools.md v1.1) |
| フロー | F1〜F4(Flows.md v1.1。F4 は 行追加 の ファイル = パス) |
| ナレッジ機能 | 登録なし |
| 参照データ | Mermaid生成規則は初期化ディレクティブなし。DCS 環境ナレッジは 構成図チェック用DCS環境ナレッジ.md |

## 注意

- ファイル名は半角英数字、中身は UTF-8(BOM なし)
- A_Docs と D_Test には SharePoint の具体的なパス・サイト名を書いていない(`<案件フォルダ>` などの置き場の名前で書く)。実際の場所は C_Agent/1_Agent/Instructions.txt と C_Agent/2_Tools/Tools.md にある(PoC 期間中の値)
- diagram と sheet の SKILL.md は、手元で編集して登録した版が正。この一式の版と違いがあれば登録した版を優先する
- v1.0 の一式(ArchReview_v1.0_FullSet_20261108)と、その後の個別の zip は、この一式に置き換わる
