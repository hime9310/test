# ホスティング判定 個別ケース(正常性確認用)― 16 件(2026-11-25 更新: 301 / 401 / 404 / 405 / 406 / 409 / 601〜604 の構成図を修正)

ホスティング判定を1件ずつ確かめるためのテストデータ。各ケースに「投稿文」「構成図(PNG)」「構成図の元データ(Mermaid)」を用意した。

## フォルダ

```
post/      RITMxxxxxxx_post.txt      Teams スレッドの最初の投稿に貼る文(ホスティング環境選定アプリの選定結果と選択内容)
png/       RITMxxxxxxx_diagram.png   スレッドとエージェントに添付する構成図
src/       RITMxxxxxxx_diagram.mmd   構成図の元データ(Mermaid)。直したいときはこれを編集して描画し直す(ライブエディター、draw.io など)
```

- post/ の文は、SharePoint にある RITMxxxxxxx.txt と同じ内容になるように作っている。違いがあれば SharePoint の txt を正とする
- 構成図はテスト用に作ったもの。投稿文の「アセットの利用用途」に合わせて、判定で見てほしい要素(Public IP の直接公開、VPC なし、VPN Gateway など)を入れてある
- Mermaid は初期化ディレクティブ(`%%{init…}%%`)を置いていない(Copilot Studio のプレビューで描画されないため)

## 1ケースの手順

1. テスト用チャンネルに、post/ の文を最初の投稿として貼り、png/ の構成図を添付して投稿する
2. 最初の投稿の「…」→「リンクをコピー」でリンクを控える
3. エージェントに(新しいチャットで)png/ の構成図を添付し、リンクを本文に貼って『RITMxxxxxxx 添付した構成図をMermaid化して』
4. 『構成図情報を抽出して』
5. 『ホスティング判定して』→ 判定環境・該当したノックアウト要件・要確認・ヒアリング文を、下の「見どころ」と自分の判断と比べる
6. 要確認でヒアリング文が出たら、スレッドに投稿して利用者役として返信し、『ホスティング再判定して』まで試してもよい
7. 記録: `RITM / 判定環境 / 該当・候補・判定不能の ID / 期待と合ったか(○△×) / 気づき / クレジット`

構成図チェックまで試すときは、判定のあとに『構成図チェックして』を続ける(環境が未定なら『環境はHubで進めて』などで先に決める)。

## ケース一覧

| RITM | CSP・選定結果 | 提供先 | シナリオ(利用用途) | 構成図の主な要素 | 判定で見どころになる点 |
|---|---|---|---|---|---|
| RITM0000101 | AWS(DCS) | 社内 | 全社員が使う基幹業務システムの統合基盤。/16 相当の CIDR | VPC /16、事業部門ごとの /20 サブネット×3、予備 /18、内部 ALB、RDS×3、Managed AD | /27 を大きく超える CIDR の扱い。特定サービスなし |
| RITM0000301 | GCP | 社外 | BigQuery の大規模データ分析基盤。GCP 必須 | GCP だけで構成(DCS Hub なし)。Cloud Armor → External HTTPS LB → Cloud Run → BigQuery、Dataflow、Cloud Storage、PSC、社内は Cloud VPN | GCP 利用(他 CSP で代替不可) |
| RITM0000401 | AWS(DCS) | 社外 | Transfer Family(SFTP)で外部取引先とファイル連携 | 外部取引先 → DCS Hub Shared Service(Network Firewall → Transit Gateway)→ Transfer Family(VPC 内部エンドポイント)→ S3 → Lambda。Elastic IP なし | Transfer Family の利用(Hub 経由の経路で、サービス自体の可否を見る) |
| RITM0000402 | Azure(DCS) | 社内 | Azure Virtual Desktop でクライアント OS(Windows 11) | AVD コントロールプレーン、Session Host(Win11 multi-session)×2、Azure Files(FSLogix)、Hub VNet ピアリング | クライアント OS の構築、AVD(PaaS)経由の接続 |
| RITM0000403 | AWS(DCS) | 社外 | 顧客向け Web のフロントに AWS Amplify。特記: Hub 利用不可 | Amplify Hosting + CloudFront + AWS WAF、API Gateway → Lambda → DynamoDB、Cognito。VPC なし、Hub なし | Amplify(CSP サービス起因で Hub 不可)、VPC なし |
| RITM0000404 | AWS(DCS) | 社外 | リアルタイムチャットに API Gateway(WebSocket API) | WebSocket API → Lambda → DynamoDB(顧客から直接)。チャット UI は Global WAF → Reverse Proxy → ALB → EC2。Cognito なし | WebSocket が Reverse Proxy を経由せず直接到達する経路 |
| RITM0000405 | AWS(DCS) | 社内 | 独自 AD ドメインのため Simple AD | 一番シンプルな構成(Hub → VPC → App Server)に Simple AD を1つ足したもの | Simple AD(独自ドメイン) |
| RITM0000406 | Azure(Disconnected) | 社外(クライアント) | クライアント拠点とのサイト間 VPN。VPN Gateway(例外申請)。CIDR 極めて大きい | 一番シンプルな構成(クライアント拠点 → VNet /16 → App VM)に VPN Gateway を1つ足したもの。DCS Hub なし | VPN Gateway の例外、/16、Disconnected |
| RITM0000407 | Azure(DCS) | 社外 | パートナー向け API を APIM で直接インターネット公開。Reverse Proxy 不採用 | Public IP 付き APIM(External)→ Function App → Private Endpoint → Azure SQL。社内運用は Hub 経由 | Reverse Proxy を使わない直接公開、Public IP |
| RITM0000408 | Azure(DCS) | 社外 | コールセンターに Azure Communication Services | ACS(PSTN・Chat)→ Event Grid → Function App → Cosmos DB。オペレーター画面は Hub → App Gateway → App Service | 顧客との通信が ACS(PaaS)に直接到達、Reverse Proxy なし |
| RITM0000409 | AWS(DCS) | 社外 | CSP 側(EC2)の Public IP で直接公開。Reverse Proxy の Public IP は使わない | Internet Gateway → Elastic IP → Web Server(EC2、Public subnet)→ App Server → RDS。社内運用は Hub 経由 | Elastic IP の利用、Reverse Proxy 不使用 |
| RITM0000501 | 要個別検討(AWS の可能性) | 社内 | Lambda + DynamoDB だけのサーバーレス。VPC 不要 | API Gateway(IAM 認証)→ Lambda → DynamoDB/S3、EventBridge、Cognito。VPC・サブネットなし | VPC なし(NW レンジ いいえ)、Hub からの到達経路 |
| RITM0000601 | AWS(DCS) | 社内 | 社内 NW への負荷試験・侵入テスト。社内 NW に影響の可能性 | 最もシンプルな構成(社内 → Hub → VPC → App Server)。判定は投稿文の文言で行う | 投稿文の「社内NWに影響を及ぼす可能性」 |
| RITM0000602 | AWS(DCS) | 社内 | セキュリティ演習のサイバーレンジ。NW・IaaS の大規模変更・破壊を繰り返す | 最もシンプルな構成(同上)。判定は投稿文の文言で行う | 投稿文の「サイバーレンジ用途: Yes」「構成変更・破壊を繰り返す」 |
| RITM0000603 | AWS(DCS) | 社内 | インシデント対応のフォレンジック調査環境。複製・解析で構成変更を繰り返す | 最もシンプルな構成(同上)。判定は投稿文の文言で行う | 投稿文の「フォレンジック用途: Yes」「構成変更を繰り返す」 |
| RITM0000604 | AWS(DCS) 本番(一時利用) | 社内 | 新人研修・製品デモ用に一時構築し、利用後に削除 | 最もシンプルな構成(同上)。判定は投稿文の文言で行う | 投稿文の「一時利用」「構成変更を伴う」 |

「判定で見どころになる点」は、投稿文と構成図に入れてある要素を書いたもの。どのノックアウト要件に当たるかは、ノックアウト要件一覧と自分の判断で決めて、エージェントの結果と比べる。

## 注意

- 同じ RITM 番号は `<案件状態 List>` に1行しか作れない。やり直すときは、List の行と `<案件フォルダ>/RITMxxxxxxx/` を削除してから
- 1ケースの判定まで(Mermaid化・抽出・判定)で、クレジットは 400〜900 程度
- 構成図を変えて試したいときは src/ の .mmd を直して描画し直す。線の色は最終行の `linkStyle default stroke:#006CFF` で付けている
