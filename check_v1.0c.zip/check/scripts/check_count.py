# -*- coding: utf-8 -*-
"""check 用 検算: 埋めた【構成図チェック結果】を読み、[ ] の残り・区分ごとの件数・検算行・節のつじつまを確かめる。

使い方: python scripts/check_count.py --result work/04_check.md --count 12   (--count は filter_points の count)
出力(JSON): counts(観点ごとの判定の行から数えた区分の件数)、kensan_line / conclusion_line(そのまま写せる行)、
            placeholders_left(残っている [ ])、unparsed_rows(読めない行)、duplicate_no、
            eng_section_mismatch(「Eng が目視で確認すること」の No と Eng目視確認 の行の No の食い違い)、
            ticket_section_mismatch(「利用者への確認・依頼」の No と 票 の行の No の食い違い)、ok。
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, parse_sections, read_input, section  # noqa: E402

# 区分の表示名(長い名前を先に置く。startswith で見分けるため)
NAMES = ["アーキテクチャレビュー票で利用者へ確認", "アーキテクチャレビュー票で利用者へ依頼", "Eng目視確認", "問題なし", "対象外"]
TICKET = "アーキテクチャレビュー票で利用者へ確認"
REQUEST = "アーキテクチャレビュー票で利用者へ依頼"
ENG = "Eng目視確認"


def nos_in(lines):
    """節の行から No を集める(「なし」や聞き返しの行は No が無いので入らない)。"""
    out = []
    for line in lines:
        m = re.match(r"No\.?\s*(\d+)", line)
        if m:
            out.append(m.group(1))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--count", type=int, required=True)
    a = ap.parse_args()
    text = read_input(a.result)
    sec = parse_sections(text)
    rows = section(sec, "観点ごとの判定")

    # 1. 「- No.X 観点名 → 区分(…)」の行から区分を数える
    counts = {n: 0 for n in NAMES}
    unknown, nos, by_name = [], [], {n: [] for n in NAMES}
    for line in rows:
        m = re.match(r"No\.?\s*(\d+)\s+(.*?)\s*→\s*([^(（｜|]+)", line)
        label = m.group(3).strip() if m else ""
        hit = next((n for n in NAMES if label.startswith(n)), None)
        if not m or not hit:
            unknown.append(line[:60])
            continue
        nos.append(m.group(1))
        counts[hit] += 1
        by_name[hit].append(m.group(1))

    # 2. 残っている [ ](チェックボックス [x] や [1] は除く)
    placeholders = [p for p in re.findall(r"\[[^\]\n]{1,40}\]", text) if not re.fullmatch(r"\[(x|X|\d+)\]", p)]

    # 3. 節のつじつま: Eng目視確認 の行 = 「Eng が目視で確認すること」の No、票の行 = 「利用者への確認・依頼」の No
    eng_nos = sorted(set(nos_in(section(sec, "Eng が目視"))), key=int)
    ticket_nos = sorted(set(nos_in(section(sec, "利用者への確認"))), key=int)
    want_eng = sorted(set(by_name[ENG]), key=int)
    want_ticket = sorted(set(by_name[TICKET] + by_name[REQUEST]), key=int)
    eng_mismatch = {"節にあるが判定はEng目視確認でない": [x for x in eng_nos if x not in want_eng],
                    "判定はEng目視確認だが節に無い": [x for x in want_eng if x not in eng_nos]}
    ticket_mismatch = {"節にあるが判定は票でない": [x for x in ticket_nos if x not in want_ticket],
                       "判定は票だが節に無い": [x for x in want_ticket if x not in ticket_nos]}
    eng_ok = not any(eng_mismatch.values())
    ticket_ok = not any(ticket_mismatch.values())

    # 4. 件数と状態行
    total = sum(counts.values())
    need = counts[ENG] + counts[TICKET] + counts[REQUEST]
    first = text.strip().split("\n")[0] if text.strip() else ""
    want_status = "要確認" if counts[ENG] else "完了"
    status_ok = not (want_status == "要確認" and "要確認" not in first)  # 要確認が必要なのに 完了 になっていたら NG
    dup = sorted({n for n in nos if nos.count(n) > 1})

    # 5. 書いてある検算行・結論の件数の行が、数え直した結果と同じか(数字の並びで比べる)
    kensan_line = f"- Eng目視確認{counts[ENG]} + アーキテクチャレビュー票で利用者へ確認{counts[TICKET]} + アーキテクチャレビュー票で利用者へ依頼{counts[REQUEST]} + 問題なし{counts['問題なし']} + 対象外{counts['対象外']} = {total}(関わる観点 {a.count} と一致)"
    conclusion_line = f"- 関わる観点 {a.count}件のうち 対応が必要 {need}件(Eng目視確認{counts[ENG]}・アーキテクチャレビュー票で利用者へ確認{counts[TICKET]}・アーキテクチャレビュー票で利用者へ依頼{counts[REQUEST]})｜問題なし {counts['問題なし']}件｜対象外 {counts['対象外']}件"
    digits = lambda s: re.findall(r"\d+", s)  # noqa: E731
    written_kensan = next((x for x in section(sec, "検算") if "=" in x), "")
    written_concl = next((x for x in section(sec, "結論") if "関わる観点" in x), "")
    kensan_ok = digits(written_kensan) == digits(kensan_line[2:])
    concl_ok = digits(written_concl) == digits(conclusion_line[2:])

    dump({
        "rows": len(rows), "count": a.count, "counts": counts, "need_action": need,
        "placeholders_left": placeholders, "unparsed_rows": unknown, "duplicate_no": dup,
        "eng_section_mismatch": eng_mismatch, "ticket_section_mismatch": ticket_mismatch,
        "expected_status": want_status, "status_line": first,
        "kensan_line": kensan_line, "kensan_line_ok": kensan_ok,
        "conclusion_line": conclusion_line, "conclusion_line_ok": concl_ok,
        "ok": (total == a.count == len(rows)) and not placeholders and not unknown and not dup
              and status_ok and eng_ok and ticket_ok and kensan_ok and concl_ok,
    })


if __name__ == "__main__":
    main()
