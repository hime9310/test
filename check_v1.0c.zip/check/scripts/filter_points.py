# -*- coding: utf-8 -*-
"""check 用: 構成図チェック観点一覧(md)を 環境・CSP・1次/2次・有効 で絞り、トリガーを機械的に評価して
「判定材料」と「【構成図チェック結果】の下書き」を作る。LLM は下書きの [ ] を埋めるだけ。

使い方:
  python scripts/filter_points.py --points work/points.md --ritm RITM1234567 --env Hub --csp AWS --phase 1次 \
      --inventory work/02_inventory.md [--answers work/06_answers.md] [--thread work/03_thread.md] [--out-draft work/draft.md]
出力(JSON): count(適用行数)、materials(LLM が判定する行)、prefilled(トリガー不成立で対象外にした行)、draft(下書き全文)。

トリガー種別の意味: 常時=必ず判定 / 存在=一覧にそのサービスがあれば判定 / 回答=回答(無ければスレッド本文)に該当があれば判定 / 存在かつ回答=両方。
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import (cell_lines, dump, find_table, first_int, get, normalize, parse_sections,  # noqa: E402
                       parse_tables, read_input, section, split_fields)

SYMBOL_NAMES = {"A": "問題なし", "B": "Eng目視確認", "C": "アーキテクチャレビュー票で利用者へ依頼",
                "D": "アーキテクチャレビュー票で利用者へ確認", "E": "対象外"}
JUDGE_VALUES = ["記載あり", "記載なし", "方向不明", "判定不能", "対象外"]


# ---------- 観点表の読み方 ----------
def parse_rule(s):
    """区分表 '記載あり→A; 記載なし→B' を {'記載あり': 'A', ...} にする。"""
    rule = {}
    for part in re.split(r"[;；\n]", s or ""):
        if "→" in part or "->" in part:
            k, v = re.split(r"→|->", part, maxsplit=1)
            rule[k.strip()] = v.strip()[:1].upper()
    return rule


def pick_ticket(cell, csp):
    """指摘概要のセル('共通: 文' / 'AWS: 文' が複数行)から、この CSP 向けの1文を選ぶ。無ければ 'なし'。"""
    lines = cell_lines(cell)
    if not lines or lines[0] == "なし":
        return "なし"
    common, mine = "", ""
    for ln in lines:
        m = re.match(r"^(共通|AWS|Azure|GCP)\s*[:：]\s*(.*)$", ln, re.I)
        if not m:
            common = common or ln
        elif m.group(1) == "共通":
            common = m.group(2).strip()
        elif m.group(1).lower() == csp.lower():
            mine = m.group(2).strip()
    return mine or common or "なし"


# ---------- 材料の読み方 ----------
def inventory_services(text):
    """【構成図一覧】のサービス一覧: ノードID｜表示ラベル｜正式名｜配置。"""
    out = []
    for line in section(parse_sections(text), "サービス一覧"):
        f = split_fields(line)
        if len(f) >= 2:
            out.append({"node": f[0], "label": f[1], "formal": f[2] if len(f) > 2 and f[2] != "-" else ""})
    return out


def exists(target, services):
    """サービス名がサービス一覧にあるか(ラベル・正式名・ノードIDの部分一致)。見つかったノード ID を返す。"""
    nt = normalize(target)
    if len(nt) < 2:
        return []
    hits = []
    for s in services:
        for name in (s["label"], s["formal"], s["node"]):
            nn = normalize(name)
            if nn and (nt in nn or (len(nn) >= 3 and nn in nt)):
                hits.append(s["node"])
                break
    return hits


def answer_rows(text):
    """06_answers.md の 回答済み / 要確認 / 未回答 の行を {no, summary, text, kind} にする。"""
    rows = []
    if not text:
        return rows
    sec = parse_sections(text)
    for kind in ("回答済み", "要確認", "未回答"):
        for line in section(sec, kind):
            f = split_fields(line)
            if len(f) >= 2 and f[0] != "なし":
                rows.append({"no": f[0], "summary": f[1], "text": f[2] if len(f) > 2 else "", "kind": kind})
    return rows


def find_answer(ticket, item, answers):
    """票の指摘概要(ticket)かトリガー対象(item)に合う回答を探す。"""
    keys = [normalize(x) for x in (ticket, item) if x and x != "なし"]
    for a in answers:
        ns = normalize(a["summary"])
        if any(k and (k in ns or ns in k) for k in keys):
            return a
    return None


def thread_hits(item, thread_text):
    """スレッド本文から、トリガー対象の語(英数字のかたまり・漢字かなのかたまり)を含む行を最大5行拾う。"""
    if not thread_text:
        return []
    key = re.split(r"[=＝]", item)[0]
    toks = []
    for t in re.findall(r"[A-Za-z0-9]+|[぀-鿿]+", key):
        if len(t) >= 2:
            toks.append(t)
            if re.match(r"[぀-鿿]", t) and len(t) > 4:
                toks.append(t[:4])  # 長い日本語は先頭4文字でも探す
    hits = [ln.strip() for ln in thread_text.split("\n") if ln.strip() and any(t.lower() in ln.lower() for t in toks)]
    return hits[:5]


# ---------- 本体 ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--points", required=True)
    ap.add_argument("--ritm", required=True)
    ap.add_argument("--env", required=True, help="Hub または Disconnected")
    ap.add_argument("--csp", required=True, help="AWS / Azure / GCP")
    ap.add_argument("--phase", required=True, help="1次 または 2次")
    ap.add_argument("--inventory", required=True)
    ap.add_argument("--answers")
    ap.add_argument("--thread")
    ap.add_argument("--out-draft")
    a = ap.parse_args()

    env = a.env.replace("DCS", "").strip()
    env_full = f"DCS {env}"
    csp = a.csp.strip()
    phase = "2次" if "2" in a.phase else "1次"

    # 1. 観点表(T_Points)と代表サービス表(T_GlobalServices)を読む
    tables = parse_tables(read_input(a.points))
    main_t = find_table(tables, header_keywords=["チェック観点", "トリガー種別"]) or tables[0]
    gs_t = find_table(tables, title_keywords=["代表サービス"], header_keywords=["サービス"])
    global_services = []
    if gs_t:
        for r in gs_t["rows"]:
            c, n = get(r, "CSP"), get(r, "サービス", "サービス名")
            if n and (not c or normalize(c) == normalize(csp)):
                global_services.append(n)

    services = inventory_services(read_input(a.inventory))
    answers = answer_rows(read_input(a.answers)) if a.answers and os.path.exists(a.answers) else []
    thread = read_input(a.thread) if a.thread and os.path.exists(a.thread) else ""

    # 2. 有効・環境・CSP・チェックタイミングで絞る
    applicable = []
    for r in main_t["rows"]:
        if not get(r, "No"):
            continue
        if normalize(get(r, "有効", default="1")) in ("0", "false", ""):
            continue
        if normalize(get(r, "環境")) not in (normalize("DCS共通"), normalize(env_full)):
            continue
        csps = [normalize(x) for x in re.split(r"[,、/\s]+", get(r, "対象CSP")) if x]
        if csps and normalize("共通") not in csps and normalize(csp) not in csps:
            continue
        if normalize(get(r, "チェックタイミング")) not in (normalize(phase), normalize("両方")):
            continue
        applicable.append(r)
    applicable.sort(key=lambda r: first_int(get(r, "No"), 0))

    # 3. 行ごとにトリガーを評価し、判定材料か「対象外」かに分ける
    materials, prefilled, draft_rows = [], [], []
    for r in applicable:
        no, name = get(r, "No"), get(r, "チェック観点")
        ttype = normalize(get(r, "トリガー種別")) or normalize("常時")
        target = get(r, "トリガー対象")
        ticket = pick_ticket(get(r, "指摘概要"), csp)

        # トリガー対象を「存在:」「回答:」の条件に分ける(「;」区切り。先頭語が無ければ種別で決める)
        exist_parts, answer_parts = [], []
        for part in [p.strip() for p in re.split(r"[;；]", target) if p.strip()]:
            if part.startswith("存在"):
                exist_parts.append(re.sub(r"^存在\s*[:：]\s*", "", part))
            elif part.startswith("回答"):
                answer_parts.append(re.sub(r"^回答\s*[:：]\s*", "", part))
            elif ttype == normalize("存在"):
                exist_parts.append(part)
            elif ttype == normalize("回答"):
                answer_parts.append(part)
            elif ttype == normalize("存在かつ回答"):
                (answer_parts if "=" in part or "＝" in part else exist_parts).append(part)

        status, evidence = "実施", ""
        # 3a. 存在: サービス一覧にあるか(「A/B」はどれか1つ、「@T_GlobalServices」は代表サービスのどれか)
        if ttype in (normalize("存在"), normalize("存在かつ回答")) or exist_parts:
            hit_nodes, miss = [], []
            for ep in exist_parts:
                cands = global_services if ep.startswith("@") else [x for x in ep.split("/") if x.strip()]
                found = [n for c in cands for n in exists(c, services)]
                if found:
                    hit_nodes += sorted(set(found))
                else:
                    miss.append(ep)
            if not hit_nodes:
                status, evidence = "対象外(利用なし)", "存在: " + " / ".join(miss or exist_parts) + " の記載なし"
            else:
                evidence = "存在: " + ", ".join(dict.fromkeys(hit_nodes))
        # 3b. 回答: 回答回収結果に該当があれば「要判定(回答)」、無ければスレッド本文を探し「要判定(スレッド)」、どちらも無ければ対象外
        if status == "実施" and (ttype in (normalize("回答"), normalize("存在かつ回答")) or answer_parts):
            item = answer_parts[0] if answer_parts else target
            ans = find_answer(ticket, item, answers)
            sep = " ｜ " if evidence else ""
            if ans:
                status, evidence = "要判定(回答)", (evidence + sep + f"回答: No.{ans['no']} {ans['summary']}: {ans['text']}")[:200]
            else:
                th = thread_hits(item, thread)
                if th:
                    status, evidence = "要判定(スレッド)", (evidence + sep + "スレッド: " + " / ".join(th))[:200]
                else:
                    status, evidence = "対象外(回答なし)", evidence + sep + f"回答: 「{item}」に該当する回答なし"

        ticket_tag = f"(票: {ticket})" if ticket != "なし" else ""   # 票に入り得る観点だけ指摘概要を添える
        if status.startswith("対象外"):
            prefilled.append({"no": no, "name": name, "status": status, "evidence": evidence})
            draft_rows.append(f"- No.{no} {name}{ticket_tag} → " + status.replace(")", f"。{evidence})", 1))
        else:
            materials.append({
                "no": no, "name": name, "category": get(r, "大分類"), "trigger": status, "evidence": evidence,
                "criteria": get(r, "判断基準"), "method": get(r, "AI判定方法"), "output": get(r, "AI出力内容"),
                "rule": parse_rule(get(r, "区分表")), "rule_text": get(r, "区分表"), "action": get(r, "対応内容"),
                "ticket": ticket, "note": get(r, "備考"),
            })
            draft_rows.append(f"- No.{no} {name}{ticket_tag} → [区分(判定値: 根拠)]")

    # 4. 下書き(LLM は [ ] だけ埋める)。No の列挙は「観点ごとの判定」だけに書く(他の節には並べない)
    n, e_pre = len(applicable), len(prefilled)
    draft = "\n".join([
        "【構成図チェック結果】状態: [完了 or 要確認]",
        "## 結論",
        f"- 処理: {phase}チェック ｜ {a.ritm} ｜ 環境: {env} ｜ CSP: {csp}",
        f"- 関わる観点 {n}件のうち 対応が必要 [NN]件(Eng目視確認[NN]・アーキテクチャレビュー票で利用者へ確認[NN]・アーキテクチャレビュー票で利用者へ依頼[NN])｜問題なし [NN]件｜対象外 [NN]件",
        "## Eng が目視で確認すること",
        "- [No.X 観点名｜構成図に○○の記載がない(確認できない)｜○○があるか目視で確認。無ければアーキテクチャレビュー票で利用者へ確認。無ければ「なし」]",
        "## 利用者への確認・依頼(アーキテクチャレビュー票で利用者へ送る文案)",
        "- [No.X(票: 指摘概要 or なし)｜理由: 構成図で○○が確認できない｜カテゴリ: サービス名｜指摘概要: 件名｜指摘内容: 文案。無ければ「なし」]",
        "## 観点ごとの判定(No順。1観点1行)",
        "\n".join(draft_rows),
        "## 要確認",
        "- [検算不一致・回答が無く対象外にした旨など。無ければ「なし」]",
        "## 検算",
        f"- Eng目視確認[NN] + アーキテクチャレビュー票で利用者へ確認[NN] + アーキテクチャレビュー票で利用者へ依頼[NN] + 問題なし[NN] + 対象外[NN] = [NN](関わる観点 {n} と一致)",
    ])
    result = {
        "ritm": a.ritm, "env": env, "csp": csp, "phase": phase, "count": n,
        "to_judge": len(materials), "prefilled_count": e_pre,
        "judge_values": JUDGE_VALUES, "symbol_names": SYMBOL_NAMES,
        "rule_default": "区分表に無い判定値は B(Eng目視確認)。トリガー不成立は E(対象外)。記号は書かず symbol_names の表示名を書く。",
        "materials": materials, "prefilled": prefilled, "draft": draft,
    }
    if a.out_draft:
        with open(a.out_draft, "w", encoding="utf-8") as f:
            f.write(draft + "\n")
        result["out_draft"] = a.out_draft
    dump(result)


if __name__ == "__main__":
    main()
