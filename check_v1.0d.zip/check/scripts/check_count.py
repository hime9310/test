# -*- coding: utf-8 -*-
"""check 用 検算: 埋めた【構成図チェック結果】を読み、[ ] の残り・節ごとの件数・No の抜けや重複・検算行を確かめる。

使い方: python scripts/check_count.py --result work/04_check.md --count 14 [--nos 1,2,3,11,13]
        (--count と --nos は filter_points の count と nos)
出力(JSON): counts(節ごとの行数)、heading_lines(そのまま写せる見出し)、kensan_line / conclusion_line(そのまま写せる行)、
            placeholders_left(残っている [ ])、heading_count_mismatch(見出しの件数と行数の食い違い)、
            missing_nos / extra_nos(--nos との食い違い)、duplicate_no、ticket_rows_malformed(票の行の形が違う)、ok。
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, parse_sections, read_input  # noqa: E402

TICKET = "アーキテクチャレビュー票で利用者へ確認・依頼"
ENG = "Eng目視確認"
# 節(見出しの先頭) → 表示名。見出しは「## 対象外(2件)」「## 利用者への確認・依頼 — …(2件)」のように件数付き
SECTIONS = [("対象外", "対象外"), ("問題なし", "問題なし"), ("利用者への確認", TICKET), ("Eng目視確認", ENG)]
TICKET_ROW = re.compile(r"^No\.?\s*(\d+)\s*[(（]票\s*[:：].*?[)）]\s*[｜|].*指摘内容\s*[:：]")  # 票作成(sheet)が読む形


def find_heading(text, prefix):
    """'## prefix…' の見出し行を返す(無ければ '')。"""
    for line in text.split("\n"):
        if line.startswith("## ") and line[3:].strip().startswith(prefix):
            return line.strip()
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--count", type=int, required=True)
    ap.add_argument("--nos", default="", help="関わる観点の No をカンマ区切りで(filter_points の nos)")
    a = ap.parse_args()
    text = read_input(a.result)
    sec = parse_sections(text)

    # 1. 節ごとに No の行を数える
    counts, by_sec, nos, unknown, malformed, heading_mismatch, headings = {}, {}, [], [], [], {}, {}
    for prefix, name in SECTIONS:
        rows = []
        for k, v in sec.items():
            if k.startswith(prefix):
                rows = v
                break
        found = []
        for line in rows:
            m = re.match(r"No\.?\s*(\d+)", line)
            if m:
                found.append(m.group(1))
                if name == TICKET and not TICKET_ROW.match(line):
                    malformed.append(line[:60])
            elif line.strip() not in ("なし", ""):
                unknown.append(f"{name}: {line[:50]}")
        counts[name] = len(found)
        by_sec[name] = found
        nos += found
        head = find_heading(text, prefix)
        hm = re.search(r"[(（](\d+)\s*件[)）]", head)
        if not head or not hm or int(hm.group(1)) != len(found):
            heading_mismatch[name] = {"見出し": head or "(無い)", "行数": len(found)}
        base = head.split("(")[0].split("（")[0].strip() if head else f"## {name}"
        headings[name] = f"{base}({len(found)}件)"

    # 2. 残っている [ ](チェックボックス [x] や [1] は除く)
    placeholders = [p for p in re.findall(r"\[[^\]\n]{1,60}\]", text) if not re.fullmatch(r"\[(x|X|\d+)\]", p)]

    # 3. No の抜け・重複(--nos があれば観点表の No と照合)
    dup = sorted({n for n in nos if nos.count(n) > 1}, key=int)
    want = [x.strip() for x in a.nos.split(",") if x.strip()]
    missing = [x for x in want if x not in nos]
    extra = [x for x in nos if want and x not in want]

    # 4. 件数・状態・検算行・結論の行
    total = sum(counts.values())
    need = counts[ENG] + counts[TICKET]
    first = text.strip().split("\n")[0] if text.strip() else ""
    want_status = "要確認" if counts[ENG] else "完了"
    status_ok = not (want_status == "要確認" and "要確認" not in first)
    kensan_line = f"- Eng目視確認{counts[ENG]} + {TICKET}{counts[TICKET]} + 問題なし{counts['問題なし']} + 対象外{counts['対象外']} = {total}(関わる観点 {a.count} と一致)"
    conclusion_line = f"- 関わる観点 {a.count}件のうち 対応が必要 {need}件(Eng目視確認{counts[ENG]}・{TICKET}{counts[TICKET]})｜問題なし {counts['問題なし']}件｜対象外 {counts['対象外']}件"
    digits = lambda s: re.findall(r"\d+", s)  # noqa: E731
    written_kensan = next((x for x in sec.get("検算", []) if "=" in x), "")
    written_concl = next((x for x in sec.get("結論", []) if "関わる観点" in x), "")
    kensan_ok = digits(written_kensan) == digits(kensan_line[2:])
    concl_ok = digits(written_concl) == digits(conclusion_line[2:])

    dump({
        "count": a.count, "counts": counts, "need_action": need, "nos_by_section": by_sec,
        "placeholders_left": placeholders, "unparsed_rows": unknown, "duplicate_no": dup,
        "missing_nos": missing, "extra_nos": extra, "heading_count_mismatch": heading_mismatch,
        "ticket_rows_malformed": malformed,
        "expected_status": want_status, "status_line": first,
        "heading_lines": headings,
        "kensan_line": kensan_line, "kensan_line_ok": kensan_ok,
        "conclusion_line": conclusion_line, "conclusion_line_ok": concl_ok,
        "ok": total == a.count and not placeholders and not unknown and not dup and not missing and not extra
              and not heading_mismatch and not malformed and status_ok and kensan_ok and concl_ok,
    })


if __name__ == "__main__":
    main()
