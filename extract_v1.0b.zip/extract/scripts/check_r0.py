# -*- coding: utf-8 -*-
"""extract 用 検算 R0: Mermaid のノード数 = 【構成図一覧】の サービス一覧 + 除外ノード か。

使い方: python scripts/check_r0.py --mermaid work/01_mermaid.md --inventory work/02_inventory.md
出力(JSON): Mermaid のノード一覧と件数、一覧側の件数、一覧に無いノード(missing)・Mermaid に無いノード(extra)、r0_line、ok。
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_tables import dump, parse_sections, read_input, section, split_fields  # noqa: E402

NODE_DEF = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(\[|\(|\{|>)")            # 例: web_server["Web Server"]
EDGE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*(-->|<-->|---|-\.->|==>)\s*(?:\|[^|]*\|\s*)?([A-Za-z_][A-Za-z0-9_]*)")  # 例: a --> b
SKIP_WORDS = {"subgraph", "end", "flowchart", "graph", "classDef", "class", "style", "linkStyle", "direction"}


def mermaid_nodes(text):
    """```mermaid ブロックからノード ID を出てきた順に集める(subgraph や style 行、枠の ID は除く)。"""
    m = re.search(r"```mermaid\s*\n(.*?)```", text, re.S)
    code = m.group(1) if m else text
    nodes, frames = [], set()
    for raw in code.split("\n"):
        line = raw.strip().rstrip(";")
        m = re.match(r"subgraph\s+([A-Za-z_][A-Za-z0-9_]*)", line)
        if m:
            frames.add(m.group(1))  # 枠(subgraph)の ID。接続の宛先に使われてもノードには数えない
        if not line or line.startswith("%%") or line.split()[0] in SKIP_WORDS:
            continue
        e = EDGE.match(line)
        ids = [e.group(1), e.group(3)] if e else ([NODE_DEF.match(line).group(1)] if NODE_DEF.match(line) else [])
        for n in ids:
            if n not in nodes:
                nodes.append(n)
    return [n for n in nodes if n not in frames]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mermaid", required=True)
    ap.add_argument("--inventory", required=True)
    a = ap.parse_args()

    nodes = mermaid_nodes(read_input(a.mermaid))
    sec = parse_sections(read_input(a.inventory))
    # 一覧の各行は「ノードID｜表示ラベル｜…」。先頭のノード ID だけ取る
    services = [split_fields(x)[0] for x in section(sec, "サービス一覧") if "｜" in x or "|" in x]
    excluded = [split_fields(x)[0] for x in section(sec, "除外ノード") if "｜" in x or "|" in x]
    listed = set(services) | set(excluded)

    missing = [n for n in nodes if n not in listed]                               # Mermaid にあるのに一覧に無い
    extra = [n for n in listed if n not in nodes and not n.endswith("(Eng追加)")]  # 一覧にあるのに Mermaid に無い
    dump({
        "mermaid_node_count": len(nodes), "mermaid_nodes": nodes,
        "service_count": len(services), "excluded_count": len(excluded),
        "missing_in_inventory": missing, "extra_in_inventory": extra,
        "r0_line": f"R0: サービス一覧{len(services)} + 除外{len(excluded)} = ノード総数{len(nodes)}",
        "ok": not missing and not extra and len(services) + len(excluded) == len(nodes),
    })


if __name__ == "__main__":
    main()
