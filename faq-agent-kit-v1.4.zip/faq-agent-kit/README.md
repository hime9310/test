# FAQ Agent 実装一式(v1.4 / 2026-11-26)

- v1.4 の変更: `02_workflows/01_OneNote_page_get.md` を、実際の画面に合わせて全体を書き直した(条件の欄の名前、「もし」と「それ以外」、動的コンテンツの選び方、セクションとページ ID を変数で渡す形)。`01_sharepoint/02_inquiry_log_list.md` の「登録日時」とビューの説明を書き直した。この README の 9章。
- v1.3 の変更: KBA の添付ファイルのリンクを、答えに示すようにした(answer-format の SKILL.md と ZIP、`05_test/test_cases.md` の #11、この README の 3章)。
- v1.2 の変更: キットと README の版をそろえた。OneNote のセクションの渡し方を、公式の記載に合わせて直した(`02_workflows/01_OneNote_page_get.md` のノード5、この README の 3章・7章・9章)。資料を整理するチームへのお願いは、別ファイル `DataSource_Design_Request_v1.0.md`。
- v1.1 の変更: 答えが無いときの問い合わせ先を「CMS」と仮のメールアドレスにした(answer-format の SKILL.md と ZIP、この README の 3章)。

Copilot Studio(New experience)で、FAQ Agent とナレッジ改善 Agent を作るための一式。
貼り付ける文面、アップロードするスキル、ワークフローとリストの作成手順書をまとめている。Copilot Studio にそのまま取り込めるパッケージではない。

実機では未確認(集計のスクリプトだけは動作を確認済み)。画面の名前が手順書と違うときは、推測で進めず、画面の写真で確かめる。
New experience は、公式ドキュメントでは Microsoft Copilot harness(ページによっては GitHub Copilot harness)と書かれている。

---

## 1. 作るもの

| 部品 | 名前 | 内容 |
|---|---|---|
| Agent | FAQ Agent | 利用者の質問に、根拠の出典付きで答える |
| Agent | ナレッジ改善 Agent | 問い合わせログを分析し、ナレッジの改善を提案する |
| ナレッジ | 各業務フォルダの「公開」 | SharePoint。FAQ Agent に登録 |
| ツール | OneNote_ページ取得 | 業務カテゴリに合うセクションのページを読む。FAQ Agent |
| ツール | 問い合わせログ_記録 | 質問と回答をリストに1行書く。FAQ Agent |
| ツール | 問い合わせログ_取得 | 期間を指定してログを読む。ナレッジ改善 Agent |
| リスト | 問い合わせログ | SharePoint List |
| スキル | answer-format / inquiry-log | FAQ Agent |
| スキル | log-analysis(Python 付き) | ナレッジ改善 Agent |

---

## 2. 中身

```
faq-agent-kit/
├─ README.md
├─ 01_sharepoint/
│   ├─ 01_folders.md              … フォルダの構成(仮)と決まり
│   └─ 02_inquiry_log_list.md     … リスト「問い合わせログ」の作り方
├─ 02_workflows/
│   ├─ 01_OneNote_page_get.md     … OneNote_ページ取得(複数セクション対応)
│   ├─ 02_inquiry_log_record.md   … 問い合わせログ_記録
│   └─ 03_inquiry_log_get.md      … 問い合わせログ_取得
├─ 03_faq_agent/
│   ├─ instructions.md            … 指示文(貼り付け用)
│   ├─ knowledge_sources.md       … ナレッジ登録の一覧(名前・説明文)
│   ├─ skills/                    … スキルの中身(編集用)
│   └─ upload/                    … アップロード用(answer-format.zip、inquiry-log.zip)
├─ 04_improvement_agent/
│   ├─ instructions.md            … 指示文(貼り付け用)
│   ├─ skills/                    … スキルの中身(編集用。Python を含む)
│   └─ upload/                    … アップロード用(log-analysis.zip)
└─ 05_test/
    ├─ test_cases.md              … テストの質問表
    ├─ sample_log.json            … 集計のスクリプトを試すためのログ(架空)
    └─ sample_summary.json        … 上のログでの正しい結果
```

スキルを直したときは、`skills/` の中身を直してから、SKILL.md が ZIP の直下に来るように ZIP を作り直す。

---

## 3. 仮に置いた前提

確認が取れていないので、次の前提で作っている。違う場合は、該当の箇所を直す。

| 項目 | 前提 | 違う場合に直す所 |
|---|---|---|
| OneNote の構成 | ノートブックの直下に、名前に業務カテゴリの語を含むセクションがある | セクション グループの中は、読めない見込み(コネクタに、グループを読む操作が無い。7章 [10])。グループを使う場合は、作り方を見直す |
| ServiceNow KBA | SharePoint のナレッジだけ。OneNote に対応するセクションは無い。KBA を取り込む仕組みは、この一式の対象外。KBA の PDF には、添付ファイルの URL を文字で表示させてある | 03_faq_agent/instructions.md の業務カテゴリ |
| Agent | 本番用を新しく作る。テストで作ったエージェントとワークフローは残す | — |
| 答えが無いときの問い合わせ先 | CMS。メールアドレスは仮(cms-support@example.com) | 03_faq_agent/skills/answer-format/SKILL.md を直し、ZIP を作り直す |
| 改善の提案の記録 | リストは作らず、チャットで返す | 後から、リストと登録用のツールを足す |

---

## 4. 作る順番

### 手順 1: SharePoint の準備

1. `01_sharepoint/01_folders.md` のとおりに、仮のフォルダとテスト用の資料を用意する。
2. `01_sharepoint/02_inquiry_log_list.md` のとおりに、リスト「問い合わせログ」を作る。

### 手順 2: ワークフロー(3本)

1. `02_workflows/01_OneNote_page_get.md`
2. `02_workflows/02_inquiry_log_record.md`
3. `02_workflows/03_inquiry_log_get.md`

ワークフローがツールの一覧に出るための条件(公式 [1])。出ないときは、ここを見る。

- トリガーが「エージェントがフローを呼び出すタイミング」(When an agent calls the flow)
- 「Respond to the agent」がある
- 「Respond to the agent」の設定の Networking で、Asynchronous response が Off
- 公開してある
- 100 秒以内に応答を返す

### 手順 3: FAQ Agent

1. New experience で、エージェントを新しく作る。
2. 指示の欄に、`03_faq_agent/instructions.md` の枠の中を貼る。
3. ナレッジ: `03_faq_agent/knowledge_sources.md` のとおりに、「公開」フォルダを1件ずつ登録する。Web の検索が有効になっていたら、無効にする。
4. ツール: OneNote_ページ取得 と 問い合わせログ_記録 を足す(公式の表記では Tools > Add a tool > Workflows)。名前、AI の説明、認証は、各ワークフローの手順書の表のとおり。
5. スキル: `03_faq_agent/upload/` の2つの ZIP を、1つずつアップロードする(公式の表記では Build タブ > Skills > Add skill > Upload a skill。公式 [3])。
6. 質問を記録することを、利用者に伝える(`01_sharepoint/02_inquiry_log_list.md` の 5章)。

### 手順 4: FAQ Agent のテスト

1. プレビューで、`05_test/test_cases.md` の 1章の #1〜#9。
2. 公開して、テストする人に共有し、その人のアカウントで #10。作成者では動き、他の利用者では動かなかったという報告があるので、早めに確かめる(9章)。

共有は、公開(Publish)の近くの共有(Share)から行う。New experience の共有で付くのは、見ることとテストの権限だけ。編集できる人(共同所有者)の足し方は、公式 [6] に従う。

### 手順 5: ナレッジ改善 Agent

1. New experience で、エージェントを新しく作る。
2. 指示の欄に、`04_improvement_agent/instructions.md` の枠の中を貼る。
3. ナレッジは登録しない。Web の検索が有効になっていたら、無効にする。
4. ツール: 問い合わせログ_取得 を足す。
5. スキル: `04_improvement_agent/upload/log-analysis.zip` をアップロードする。

### 手順 6: ナレッジ改善 Agent のテスト

`05_test/test_cases.md` の 2章と 3章。

### 手順 7: 公開

FAQ Agent は、利用者に共有する。ナレッジ改善 Agent は、ナレッジ運用チームだけに共有する。

---

## 5. 名前(仮)

| 部品 | 仮の名前 |
|---|---|
| FAQ Agent | CMS_FAQ_Agent |
| ナレッジ改善 Agent | CMS_Knowledge_Improve_Agent |
| リスト | 問い合わせログ(作るときは InquiryLog) |
| ビュー | LogExport |

---

## 6. 進め方の決まり

- ワークフローは式を使わない。文字と動的コンテンツだけで作る。
- 動的コンテンツは名前が途中で切れるので、説明の文で見分ける。
- 画面の名前が手順書と違うときは、推測で進めず、写真で確かめる。
- ファイルは UTF-8(BOM なし)。出し直すときは、新しい版の名前にする。

---

## 7. 制限と費用(公式の記載)

| 項目 | 公式の記載(英語のまま) | 対象 | この一式での対処 | URL |
|---|---|---|---|---|
| ワークフローの応答時間 | Respond to the agent within the 100-second action limit. | New experience | OneNote はキーワードで絞る。`*` は手動のテストだけで使う | [1] |
| ワークフローのツールの打ち切り | Workflow tool timeout: 660 seconds (11 minutes) | New experience | [1] と数字が違う。短い方の 100 秒に収める | [2] |
| ツール呼び出しの打ち切り | Tool call timeout: 120 seconds(an ordinary tool call, such as a connector call or a knowledge search) | New experience | — | [2] |
| Teams での表示 | Teams ends a streamed response after two minutes … so the answer can appear twice. | New experience | 応答が長いと、答えが2回見えることがある | [2] |
| OneNote コネクタの呼び出し回数 | API calls per connection: 100 calls / Renewal period: 60 seconds | OneNote コネクタ | ページの本文は、キーワードに合うものだけを取る。`*` は手動のテストだけで使う | [10] |
| スキルのファイル | A ZIP file that must include a SKILL.md file / Save SKILL.md as UTF-8 without a byte-order mark | New experience | `upload/` の ZIP は、この形にしてある | [3] |
| SharePoint の URL の数 | Each agent can have a maximum of 25 SharePoint site URLs when the agent is using generative orchestration. | 標準ハーネス | 「公開」フォルダの単位で登録し、件数を抑える | [4] |
| SharePoint のファイル サイズ | For makers without the Microsoft 365 Copilot license in the same tenant as their agent, … generative answers can only use SharePoint files that are under 7 MB. | 標準ハーネス | 7 MB 以上の資料は控えておき、分ける | [4] |
| 作成者の資格情報 | By default, both End-user and Maker-provided credentials are enabled.(管理者が Control maker credential options で変えられる) | 記載なし | 問い合わせログ_記録 で使う。選べないときは `02_inquiry_log_list.md` の 4章 | [5] |
| 課金の始まり | Billing starts when you start building. | New experience | テストのたびに、クレジットを記録する | [7] |
| 課金の対象 | Copilot Credits are charged for large language model (LLM) tokens, tools (including knowledge and MCPs), and the harness itself. | New experience | ツールが返す文章を減らす(キーワード、LogExport のビュー) | [7] |
| M365 Copilot ライセンス | This usage isn't included with a user's Microsoft 365 Copilot license. | New experience | ライセンスがあっても課金される前提で見積もる | [8] |

「標準ハーネス」の行は、New experience にも当てはまるかが公式に書かれていない。
クレジットの消費は、プレビューの表示と、エージェントの監視(Monitor)で見る。

- [1] https://learn.microsoft.com/en-us/microsoft-copilot-studio/workflows-experience/flow-agent
- [2] https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/runtime-limits
- [3] https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/skills-add-existing
- [4] https://learn.microsoft.com/en-us/microsoft-copilot-studio/requirements-quotas
- [5] https://learn.microsoft.com/en-us/microsoft-copilot-studio/configure-no-maker-authentication
- [6] https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/authoring-share-agent
- [7] https://learn.microsoft.com/en-us/microsoft-copilot-studio/agents-experience/billing-credit-overview
- [8] https://learn.microsoft.com/en-us/power-platform/admin/manage-usage-microsoft-copilot-harness
- [9] https://learn.microsoft.com/en-us/answers/questions/6026656/copilot-studio-published-public-agent-cannot-invok (利用者からの報告。公式の回答ではない)
- [10] https://learn.microsoft.com/en-us/connectors/onenote/

---

## 8. 業務カテゴリの名前を変える・増やすとき

直す所は次の4つ。ワークフローは直さなくてよい。

| 直す所 | すること |
|---|---|
| SharePoint | 業務フォルダと、その下の「公開」「非公開」を作る(名前を変える) |
| FAQ Agent のナレッジ | 「公開」の URL を登録する。名前と説明文を書く(`knowledge_sources.md` にも足す) |
| FAQ Agent の指示文 | 「# 業務カテゴリ」の一覧を直す |
| OneNote | 名前に業務カテゴリの語を含むセクションを作る |

SharePoint のフォルダ名を変えると URL が変わる。その場合は、ナレッジを登録し直す。

---

## 9. 確認が済んでいないこと

| 項目 | 内容 | 確かめ方 |
|---|---|---|
| 作成者以外の利用者 | New experience で、ワークフローのツールが作成者では動き、他の利用者では動かなかったという報告がある(未解決 [9]) | 手順 4 の 2 |
| 利用者のライセンス | 共有の前提条件に「Users you share with have a Microsoft Copilot Studio per-user license.」とある [6]。Teams で使うだけの利用者にも要るかは、書かれていない | 環境の管理者か MS に聞く |
| 作成者の接続 | 問い合わせログ_記録 を、作成者の接続で動かせるか。環境の設定で禁止できる [5] | ツールの認証の画面。だめなら `02_inquiry_log_list.md` の 4章 |
| OneNote のセクション | 「ノートブックのセクション」の欄に、セクション キーを直接入れるとエラーになった(実機)。変数を経由して渡す形に変えた。変数で渡せるかは確認中 | `01_OneNote_page_get.md` のノード5・6。だめな場合の作り方も書いてある |
| スキルの Python | このエージェントでもスクリプトが動くか(アーキテクチャレビューのエージェントと同じ環境なら動く見込み) | `test_cases.md` の 3章 |
| ナレッジの制限 | SharePoint の URL の数とファイル サイズの上限が、New experience にも当てはまるか | MS への問い合わせの回答 |
