#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""問い合わせログを集計して summary.json を出力する。標準ライブラリのみ。

使い方:
    python analyze_log.py <log.json> [<summary.json>]

入力: ツール「問い合わせログ_取得」の出力(JSON)。次のどの形でも読める。
    - 行の配列              [ {...}, {...} ]
    - value に配列を持つ形    { "value": [ {...} ] }
    - 出力の名前で包まれた形   { "ログ": ... }
    - 上記が文字列として包まれた形
出力: 件数の集計、記載なしの質問の一覧、似た質問のまとまり、提案の候補。
"""
import json
import os
import re
import sys
import unicodedata
from collections import Counter

# List の列(内部名)。左から順に探す。日本語の表示名でも読めるようにしてある。
KEYS = {
    "title": ["Title", "質問の要約"],
    "question": ["Question", "質問"],
    "answer": ["AnswerSummary", "回答要約"],
    "category": ["Category", "業務カテゴリ"],
    "result": ["Result", "回答可否"],
    "source": ["Source", "出典"],
    "created": ["Created", "登録日時"],
}

SIMILARITY_THRESHOLD = 0.34   # これ以上なら「似た質問」とみなす(目安)
MAX_UNANSWERED_LISTED = 200
MAX_EXAMPLES = 5
TOP_SOURCES = 20

# 似ているかの判定の前に取り除く、質問の決まり文句
STOP_PHRASES = [
    "教えてください", "教えて下さい", "教えてほしいです", "教えて",
    "知りたいです", "知りたい", "でしょうか", "ですか", "ますか",
    "について", "に関して", "ください", "下さい", "方法", "やり方",
    "どうすれば", "どのように", "どこから", "どこで", "どこ", "いつ",
    "したいです", "したい", "できますか", "できる", "必要です", "必要",
    "です", "ます",
]


WRAP_KEYS = ("value", "ログ", "body", "items", "output", "outputs", "result")
ROW_KEYS = ("Question", "Title", "質問", "質問の要約")


def load_rows(path):
    with open(path, encoding="utf-8-sig") as f:
        data = json.load(f)
    for _ in range(8):                      # 包みを外側から順に開く
        if isinstance(data, list):
            break
        if isinstance(data, str):           # 文字列として包まれている
            data = json.loads(data)
        elif isinstance(data, dict):
            if any(k in data for k in ROW_KEYS):
                data = [data]               # 1行だけがそのまま入っている
                break
            for key in WRAP_KEYS:           # value や、出力の名前で包まれている
                if key in data:
                    data = data[key]
                    break
            else:
                break
        else:
            break
    if not isinstance(data, list):
        raise ValueError("ログの形を読めません。行の配列か、value に配列を持つ形にしてください。")
    return [r for r in data if isinstance(r, dict)]


def pick(row, name):
    for key in KEYS[name]:
        value = row.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return ""


def result_kind(text):
    if "記載なし" in text:
        return "記載なし"
    if "回答" in text:
        return "回答"
    return "その他"


def split_sources(text):
    parts = re.split(r"[\n\r、,;；]+|\s/\s", text)
    return [p.strip() for p in parts if p.strip() and p.strip() != "なし"]


def bigrams(text):
    s = unicodedata.normalize("NFKC", text).lower()
    for phrase in STOP_PHRASES:
        s = s.replace(phrase, "")
    s = re.sub(r"[^\w]", "", s)             # 記号と空白を除く
    s = re.sub(r"[はをがのにでとも]", "", s)   # 助詞を除く(大まかな判定のため)
    if len(s) < 2:
        return {s} if s else set()
    return {s[i:i + 2] for i in range(len(s) - 1)}


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def cluster(records):
    clusters = []
    for rec in records:
        best, best_score = None, 0.0
        for c in clusters:
            score = max(jaccard(rec["grams"], m["grams"]) for m in c[:8])
            if score > best_score:
                best, best_score = c, score
        if best is not None and best_score >= SIMILARITY_THRESHOLD:
            best.append(rec)
        else:
            clusters.append([rec])
    return clusters


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    log_path = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        os.path.dirname(os.path.abspath(log_path)), "summary.json")

    try:
        rows = load_rows(log_path)
    except (OSError, ValueError) as e:      # JSON として読めない場合も ValueError
        print(f"ログを読めませんでした: {e}")
        sys.exit(1)
    records = []
    for row in rows:
        question = pick(row, "question") or pick(row, "title")
        if not question:
            continue
        records.append({
            "question": question,
            "category": pick(row, "category") or "(未分類)",
            "result": result_kind(pick(row, "result")),
            "sources": split_sources(pick(row, "source")),
            "created": pick(row, "created"),
            "grams": bigrams(question),
        })

    total = len(records)
    by_result = Counter(r["result"] for r in records)
    categories = Counter(r["category"] for r in records)
    unanswered_by_cat = Counter(r["category"] for r in records if r["result"] == "記載なし")
    source_count = Counter(s for r in records for s in r["sources"])
    dates = sorted(r["created"] for r in records if r["created"])

    cluster_list = []
    for i, members in enumerate(sorted(cluster(records), key=len, reverse=True), start=1):
        if len(members) < 2:
            continue
        srcs = Counter(s for m in members for s in m["sources"])
        cluster_list.append({
            "id": i,
            "size": len(members),
            "answered": sum(1 for m in members if m["result"] == "回答"),
            "unanswered": sum(1 for m in members if m["result"] == "記載なし"),
            "categories": sorted({m["category"] for m in members}),
            "sources": [{"source": s, "count": n} for s, n in srcs.most_common()],
            "representative": members[0]["question"],
            "examples": [m["question"] for m in members[:MAX_EXAMPLES]],
        })

    shortage = [c["id"] for c in cluster_list if c["unanswered"] >= 2]
    revise = [c["id"] for c in cluster_list if c["answered"] >= 3 and len(c["sources"]) <= 1]
    duplicate = [c["id"] for c in cluster_list if c["answered"] >= 2 and len(c["sources"]) >= 2]

    summary = {
        "period": {"from": dates[0] if dates else "", "to": dates[-1] if dates else ""},
        "total": total,
        "by_result": {k: by_result.get(k, 0) for k in ("回答", "記載なし", "その他")},
        "unanswered_rate": round(by_result.get("記載なし", 0) / total, 3) if total else 0,
        "by_category": [
            {"category": c, "total": n, "unanswered": unanswered_by_cat.get(c, 0)}
            for c, n in categories.most_common()
        ],
        "top_sources": [{"source": s, "count": n} for s, n in source_count.most_common(TOP_SOURCES)],
        "unanswered_questions": [
            {"created": r["created"], "category": r["category"], "question": r["question"]}
            for r in records if r["result"] == "記載なし"
        ][:MAX_UNANSWERED_LISTED],
        "clusters": cluster_list,
        "candidates": {
            "shortage": shortage,     # 不足: 記載なしが2件以上あるまとまり
            "revise": revise,         # 修正: 同じ出典で3件以上くり返し聞かれているまとまり
            "duplicate": duplicate,   # 重複: 同じ話題に別々の出典が使われているまとまり
        },
        "note": "まとまりは文字の重なりによる目安。提案を書く前に、質問文を読んで同じ話題か確かめること。",
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(f"総件数: {total}")
    print(f"回答: {summary['by_result']['回答']} / 記載なし: {summary['by_result']['記載なし']}"
          f" / その他: {summary['by_result']['その他']}")
    print(f"似た質問のまとまり(2件以上): {len(cluster_list)}")
    print(f"候補 不足: {len(shortage)} / 修正: {len(revise)} / 重複: {len(duplicate)}")
    print(f"出力: {out_path}")


if __name__ == "__main__":
    main()
